PIE REALTY WEBSITE — QUICK SETUP

Files:
- index.html: complete responsive single-page website.

BEFORE GOING LIVE:
1. Open index.html in a text editor.
2. Search for: const WHATSAPP_NUMBER = "918796909900";
3. Replace with your business WhatsApp number including country code, digits only.
   Example format for India: 919876543210 (do not use + or spaces).
4. Replace sample property cards with real listings, verified location, area and pricing.
5. Add your actual contact details and any required legal/privacy information.

PREVIEW:
Double-click index.html to preview in a modern browser.

CUSTOM DOMAIN / PUBLISHING:
This folder is a website starter; it is not automatically live on the internet. To use a custom domain, purchase/register your preferred domain, upload index.html to a hosting provider, and connect the domain using the host's DNS instructions. Domain availability and price must be checked with a registrar. No domain has been purchased or connected by this package.

FUNCTIONALITY:
- Responsive luxury black-and-gold design.
- Listing category filters.
- WhatsApp enquiry links for property cards.
- Buyer / seller / broker lead form that prepares a WhatsApp message.
- No server or database is included; form messages open in WhatsApp for the visitor to send.
